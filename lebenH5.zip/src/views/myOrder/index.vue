<template>
  <div class="myOrderBox">
    <FunOrderHeader></FunOrderHeader>
  </div>
</template>

<script>
import FunOrderHeader from "./components/funOrderHeader";
export default {
  components: {
    FunOrderHeader,
  },

  data() {
    return {};
  },
};
</script>

<style lang="scss" scoped>

</style>