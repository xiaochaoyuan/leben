<template>
  <div class="myOrderBox">
    <funOrderHeader></funOrderHeader>
  </div>
</template>

<script>
import funOrderHeader from "./components/funOrderHeader";
export default {
  components: {
    funOrderHeader,
  },

  data() {
    return {};
  },
};
</script>

<style lang="scss" scoped>

</style>